# Phase Build Plan

## Overview

| Phase | What | Duration | VPS Needed? |
|---|---|---|---|
| 0 | Local infra + instruments | 1–2 hours | No |
| 1 | Tick ingestion pipeline | 1 week | No (but move at end) |
| 2 | FastAPI + alert engine | 1 week | Yes |
| 3 | Chatbot + Telegram | 1 week | Yes |
| 4 | ML models | 3–4 weeks | Yes |
| 5 | Terminal UI upgrade | 1 week | Yes |

---

## Phase 0 — Local Infra (Do This Today)

**Goal**: ClickHouse, Postgres, Kafka, Redis running locally. Instrument list loaded.

### Tasks
- [ ] Copy `.env.example` to `.env`, fill in Upstox credentials
- [ ] Run `./scripts/bootstrap.sh` — starts Docker Compose, runs ClickHouse + Postgres migrations
- [ ] Run `python scripts/seed_instruments.py` — fetches NSE company list, filters market cap > ₹10,000 Cr, inserts into Postgres
- [ ] Verify: `docker compose ps` shows all containers healthy

### Milestone
```
docker exec clickhouse clickhouse-client --query "SHOW TABLES FROM market"
# Should show: ticks, ohlcv_1m
```

---

## Phase 1 — Tick Ingestion Pipeline

**Goal**: Raw ticks from Upstox flowing into ClickHouse in real-time during market hours.

### Tasks (in order)
- [ ] `src/ingestion/tick_writer.py` — write the buffered ClickHouse inserter first, test with mock data
- [ ] `src/ingestion/kafka_producer.py` — publish decoded ticks to Kafka
- [ ] `src/ingestion/upstox_ws.py` — connect to Upstox WS, decode protobuf, pipe to writer + kafka
- [ ] `src/ingestion/watchdog.py` — gap detection, reconnect logic

### Test During Market Hours
```bash
python -m src.ingestion.upstox_ws
# Wait 5 minutes, then:
docker exec clickhouse clickhouse-client \
  --query "SELECT symbol, count() FROM market.ticks GROUP BY symbol LIMIT 20"
```

### Milestone
10+ ticks per second flowing into ClickHouse for all subscribed symbols during market hours. **Move to VPS at this point.**

---

## Phase 2 — FastAPI + Alert Engine

**Goal**: REST API serving tick data, and alert rules evaluating in real-time with Telegram delivery.

### Tasks
- [ ] `src/api/db/clickhouse.py` + `src/api/db/postgres.py` — DB singletons
- [ ] `src/api/routes/ticks.py` — GET /ticks, GET /ohlcv, GET /quote
- [ ] `src/api/routes/alerts.py` — POST /alerts, GET /alerts, DELETE /alerts/{id}
- [ ] `src/api/alert_engine.py` — loads rules from Redis, evaluates on each tick, calls Telegram
- [ ] `src/chatbot/telegram_bot.py` (basic) — just delivery for now, no NLP yet
- [ ] `src/api/main.py` — wire up FastAPI + WebSocket endpoint

### Test
```bash
curl http://localhost:8000/quote?symbol=RELIANCE
# {"success": true, "data": {"ltp": 2948.50, "bid": 2948.00, "ask": 2949.00}}

curl -X POST http://localhost:8000/alerts \
  -H "Content-Type: application/json" \
  -d '{"symbol": "RELIANCE", "condition": "price > 2950", "channel": "telegram"}'
```

### Milestone
Alert fires on Telegram when a threshold is crossed.

---

## Phase 3 — Chatbot + NLP Layer

**Goal**: Client can type natural language into a chat panel or Telegram and set alerts, get quotes, ask market questions.

### Tasks
- [ ] `src/chatbot/intent_parser.py` — Claude API call with NLP system prompt, returns structured JSON
- [ ] `src/chatbot/handlers.py` — one function per intent: market_query, alert_set, alert_cancel, ml_signal, order_place
- [ ] `src/chatbot/formatter.py` — takes raw handler output, calls Claude API to format natural reply
- [ ] `src/api/routes/chat.py` — FastAPI endpoint wiring
- [ ] Upgrade `telegram_bot.py` — full NLP loop (receive → parse → handle → reply)
- [ ] Add order confirmation guard — never place order without "YES" confirmation

### Test Phrases to Try
```
"What is the PCR on Nifty right now?"
"Alert me when Reliance crosses 2950"
"Show me Nifty 50 stocks with RSI below 30"
"Cancel all my alerts"
"Which sectors are outperforming today?"
```

### Milestone
Full conversation loop working end-to-end in Telegram, including alert set + fire + cancel.

---

## Phase 4 — ML Pipeline

**Goal**: Buy/sell/hold signals with confidence scores for all 500 symbols, updated on each candle close.

### Tasks (in order — do not skip ahead)
- [ ] `src/ml/features.py` — full feature engineering (RSI, MACD, BB, ATR, VWAP, OFI, volume_z, spread, bid_ask_imbalance)
- [ ] Export 6 months of Parquet data from ClickHouse for training
- [ ] `src/ml/regime.py` — train HMM regime classifier first (trending/ranging/high-vol). This is an input feature for everything else.
- [ ] `src/ml/signals_xgb.py` — train XGBoost with regime as a feature. Add SHAP value logging.
- [ ] `src/api/routes/signals.py` — inference endpoint
- [ ] Extend chatbot handler for `ml_signal` intent — "what's the AI signal on HDFC today?"
- [ ] `src/ml/lstm_price.py` — optional, add after XGBoost is validated

### Training Schedule
- Train on weekends only (Sat/Sun after market)
- Never retrain during market hours
- Keep last 3 model versions in `models/` directory for rollback

### Milestone
```
curl http://localhost:8000/signals/RELIANCE
# {"signal": "buy", "confidence": 0.74, "regime": "trending",
#  "shap": {"rsi_14": 0.12, "ofi_10": 0.08, "volume_z": 0.06}}
```

---

## Phase 5 — Terminal UI

**Goal**: Polished web terminal with live ticks, charts, chat panel, signal dashboard.

### Tasks
- [ ] Base layout — top bar (Nifty index), main grid (watchlist + chart), bottom bar (status)
- [ ] `src/ui/charts.js` — Lightweight Charts candlestick with live updates via WebSocket
- [ ] Nifty 50 heatmap — sector-colored grid of all 50 stocks
- [ ] `src/ui/chat_panel.js` — floating chat overlay, wired to `/chat` endpoint
- [ ] Signal dashboard panel — table of top signals with confidence + SHAP explanation
- [ ] F&O panel — OI buildup chart, PCR, IV surface (if options data available)

### Milestone
Full terminal running in browser, chat panel functional, live ticks updating charts.

---

## Post-Phase 5 — Enhancements (Backlog)

- [ ] Strategy backtester tab — replay historical signals against actual prices
- [ ] Auto trade journal — every order logged with market context
- [ ] Multi-user support — session management, per-user alert rules
- [ ] FinBERT news sentiment — score NSE news releases, earnings calls
- [ ] Reinforcement Learning (PPO) — portfolio allocation (hardest, save for last)
- [ ] Mobile app — React Native wrapper around the chatbot + alerts

---

## Notes on Sequencing

**Don't jump to ML before ingestion is solid.** Bad ticks produce bad features, which produce wrong signals, which are worse than no signals. Get a full week of clean data first.

**Don't build UI before the API is working.** The UI is just a consumer of the API. Build it last so you can test with curl first.

**The chatbot is your client-facing differentiator.** Even before ML is ready, a working chatbot that answers "what's the current price of Infosys?" and sets Telegram alerts is already something clients will love. Ship Phase 3 before you go deep on Phase 4.
