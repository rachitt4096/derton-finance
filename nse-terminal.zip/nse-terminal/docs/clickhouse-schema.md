# ClickHouse Schema Reference

## Setup (run once)

```sql
CREATE DATABASE IF NOT EXISTS market;
```

---

## `ticks` — Main Tick Table

```sql
CREATE TABLE market.ticks (
    ts        DateTime64(3, 'Asia/Kolkata'),   -- millisecond precision, IST
    symbol    LowCardinality(String),           -- ~500 symbols, huge compression win
    ltp       Float32,                          -- last traded price
    volume    UInt32,                           -- traded volume this tick
    bid       Float32,
    ask       Float32,
    oi        UInt32,                           -- open interest (for F&O symbols)
    bid_qty   UInt32,
    ask_qty   UInt32
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(ts)                       -- one partition per month
ORDER BY (symbol, ts)                           -- primary sort key
TTL ts + INTERVAL 2 YEAR                        -- auto-purge after 2 years
SETTINGS index_granularity = 8192;
```

### Why `LowCardinality(String)` for symbol?
With ~500 symbols repeated billions of times, ClickHouse stores them as a dictionary (integer IDs). Storage drops by ~80% for that column, and filtering by symbol becomes integer comparison.

### Why ORDER BY (symbol, ts)?
Any query like `WHERE symbol = 'RELIANCE' AND ts BETWEEN X AND Y` skips ~99% of data via sparse index. Without this, it would full-scan the table.

---

## `ohlcv_1m` — 1-Minute Candles (Continuous Aggregate)

```sql
CREATE MATERIALIZED VIEW market.ohlcv_1m
ENGINE = AggregatingMergeTree()
PARTITION BY toYYYYMM(bucket)
ORDER BY (symbol, bucket)
AS
SELECT
    symbol,
    toStartOfMinute(ts)         AS bucket,
    argMinState(ltp, ts)        AS open_state,
    maxState(ltp)               AS high_state,
    minState(ltp)               AS low_state,
    argMaxState(ltp, ts)        AS close_state,
    sumState(volume)            AS volume_state
FROM market.ticks
GROUP BY symbol, bucket;
```

Query it:
```sql
SELECT
    symbol,
    bucket,
    argMinMerge(open_state)  AS open,
    maxMerge(high_state)     AS high,
    minMerge(low_state)      AS low,
    argMaxMerge(close_state) AS close,
    sumMerge(volume_state)   AS volume
FROM market.ohlcv_1m
WHERE symbol = 'RELIANCE'
  AND bucket >= now() - INTERVAL 1 DAY
GROUP BY symbol, bucket
ORDER BY bucket;
```

---

## Useful Queries

### Latest price per symbol
```sql
SELECT symbol, argMax(ltp, ts) AS last_price
FROM market.ticks
WHERE ts > now() - INTERVAL 5 MINUTE
GROUP BY symbol
ORDER BY symbol;
```

### Tick count today
```sql
SELECT symbol, count() AS ticks
FROM market.ticks
WHERE ts >= toDate(now())
GROUP BY symbol
ORDER BY ticks DESC
LIMIT 20;
```

### Volume spike detection (last 5 min vs 30 min average)
```sql
WITH
  recent AS (
    SELECT symbol, sum(volume) AS vol_5m
    FROM market.ticks
    WHERE ts > now() - INTERVAL 5 MINUTE
    GROUP BY symbol
  ),
  baseline AS (
    SELECT symbol, sum(volume) / 6 AS vol_avg_5m
    FROM market.ticks
    WHERE ts BETWEEN now() - INTERVAL 30 MINUTE AND now() - INTERVAL 5 MINUTE
    GROUP BY symbol
  )
SELECT r.symbol, r.vol_5m, b.vol_avg_5m,
       round(r.vol_5m / b.vol_avg_5m, 2) AS spike_ratio
FROM recent r JOIN baseline b ON r.symbol = b.symbol
WHERE spike_ratio > 2
ORDER BY spike_ratio DESC;
```

### Table size on disk
```sql
SELECT
    table,
    formatReadableSize(sum(bytes_on_disk)) AS size,
    sum(rows)                              AS total_rows
FROM system.parts
WHERE database = 'market' AND active
GROUP BY table;
```

---

## Storage Estimates

| Period | Raw ticks (500 symbols) | ClickHouse ZSTD |
|---|---|---|
| 1 day | ~6.5 GB | ~200–300 MB |
| 1 month | ~130 GB | ~4–6 GB |
| 1 year | ~1.5 TB | ~55–70 GB |
| 2 years | ~3 TB | ~120 GB |

A 200 GB NVMe comfortably holds 2+ years.
