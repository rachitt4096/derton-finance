# API Reference

Base URL: `http://localhost:8000` (dev) / `https://yourdomain.com/api` (prod)

All responses: `{ "success": bool, "data": any, "error": string | null }`

---

## Health

### `GET /health`
Returns service status.
```json
{"success": true, "data": {"status": "ok", "tick_lag_ms": 45}}
```

---

## Quotes & Ticks

### `GET /quote?symbol=RELIANCE`
Current price snapshot from Redis cache.
```json
{
  "success": true,
  "data": {
    "symbol": "RELIANCE",
    "ltp": 2948.50,
    "bid": 2948.00,
    "ask": 2949.00,
    "volume": 1234567,
    "change_pct": 1.24,
    "ts": "2025-06-10T14:23:45.123+05:30"
  }
}
```

### `GET /ticks?symbol=RELIANCE&from=2025-06-10T09:15:00&to=2025-06-10T10:00:00`
Raw ticks for a symbol in a time range (ClickHouse query).
```json
{
  "success": true,
  "data": [
    {"ts": "...", "ltp": 2948.50, "volume": 100, "bid": 2948.0, "ask": 2949.0},
    ...
  ]
}
```

### `GET /ohlcv?symbol=RELIANCE&resolution=1m&limit=100`
OHLCV candles. Resolution: `1m`, `5m`, `15m`, `1h`, `1d`.
```json
{
  "success": true,
  "data": [
    {"bucket": "2025-06-10T09:15:00", "open": 2940, "high": 2952, "low": 2938, "close": 2948, "volume": 450000},
    ...
  ]
}
```

---

## Instruments

### `GET /instruments?q=hdfc&limit=10`
Search instruments by name or symbol.

### `GET /instruments/{symbol}`
Full metadata for a symbol.
```json
{
  "success": true,
  "data": {
    "symbol": "HDFCBANK",
    "name": "HDFC Bank Ltd",
    "sector": "Financial Services",
    "market_cap": 1234567000000,
    "isin": "INE040A01034",
    "lot_size": 550,
    "tick_size": 0.05
  }
}
```

---

## Alerts

### `POST /alerts`
Create an alert rule.
```json
// Request
{
  "symbol": "RELIANCE",
  "condition": "price > 2950",
  "channel": "telegram",
  "user_id": "user123"
}
// Response
{
  "success": true,
  "data": {"id": "uuid", "created_at": "..."}
}
```

Supported conditions:
- `price > 2950`
- `price < 2900`
- `rsi_14 < 30`
- `rsi_14 > 70`
- `volume_spike > 2` (2x 30-min average)

### `GET /alerts?user_id=user123`
List all active alerts for a user.

### `DELETE /alerts/{alert_id}`
Delete an alert rule.

### `PATCH /alerts/{alert_id}/toggle`
Toggle alert active/inactive.

---

## Chat

### `POST /chat`
Send a message to the AI trading assistant.
```json
// Request
{
  "message": "Alert me when Reliance crosses 2950",
  "session_id": "session_abc",
  "user_id": "user123"
}
// Response
{
  "success": true,
  "data": {
    "reply": "Done! I've set an alert for RELIANCE when price crosses ₹2,950 upward. You'll get a Telegram notification when it triggers.",
    "intent": "alert_set",
    "alert_id": "uuid"
  }
}
```

---

## ML Signals

### `GET /signals/{symbol}`
Current ML signal for a symbol.
```json
{
  "success": true,
  "data": {
    "symbol": "RELIANCE",
    "signal": "buy",
    "confidence": 0.74,
    "regime": "trending",
    "shap": {
      "ofi_10": 0.12,
      "rsi_14": 0.09,
      "volume_z_score": 0.07
    },
    "model": "xgboost_v3",
    "ts": "2025-06-10T14:23:00+05:30"
  }
}
```

### `GET /signals?filter=buy&min_confidence=0.7&limit=20`
Top signals across all symbols. Optional filters: `buy|sell|hold`, min confidence threshold.

---

## WebSocket

### `WS /ws/terminal`
Real-time tick stream. Connect and subscribe to symbols.

```javascript
// Subscribe
ws.send(JSON.stringify({
  type: "subscribe",
  symbols: ["RELIANCE", "TCS", "INFY"]
}))

// Incoming tick message
{
  "type": "tick",
  "symbol": "RELIANCE",
  "ltp": 2948.50,
  "volume": 100,
  "ts": "2025-06-10T14:23:45.123+05:30"
}

// Incoming alert fire message
{
  "type": "alert_fired",
  "alert_id": "uuid",
  "symbol": "RELIANCE",
  "message": "RELIANCE crossed ₹2,950 — now at ₹2,951.25"
}
```
