# System Architecture

## Data Flow Overview

```
Upstox WebSocket
       │
       ▼
upstox_ws.py  ──────────────────────────────┐
  (decoder)                                  │
       │                                     │
       ├──► Kafka (ticks.raw) ◄──────────   │
       │         │                    │      │
       │         ▼                    │      ▼
       │   Kafka Streams          Alert    ClickHouse
       │   (1m OHLCV agg)       Engine   (tick storage)
       │         │                    │
       │         ▼                    ▼
       │   ticks.ohlcv.1m      Telegram Bot
       │
       ▼
  Feature Store (Redis)
  RSI, MACD, OFI, VWAP...
       │
       ▼
  ML Models
  XGBoost → LSTM → Regime
       │
       ▼
  FastAPI (/signals, /chat, /ticks, /alerts)
       │
       ├──► Terminal UI (WebSocket)
       └──► Chatbot (Claude API → NLP)
```

---

## Component Responsibilities

### Ingestion Layer
- **upstox_ws.py**: Connects to Upstox WS, decodes protobuf feed, fans out to Kafka + ClickHouse buffer. Handles reconnect with backoff.
- **tick_writer.py**: Buffers ticks in memory, batch-inserts to ClickHouse every 1 second or 5000 rows.
- **kafka_producer.py**: Publishes raw ticks to `ticks.raw` (keyed by symbol for ordering).
- **watchdog.py**: Monitors tick rate per symbol, detects gaps > 30 seconds during market hours, logs to Postgres.

### Storage Layer
- **ClickHouse**: All tick data. Partitioned by month, ordered by (symbol, ts). ZSTD compression. Continuous aggregates for OHLCV candles.
- **PostgreSQL**: Everything relational — instruments master, alert rules, ML signal log, chat history, trade journal.
- **Redis**: Hot cache for active alert rules (sub-millisecond lookup per tick). Also pub/sub for real-time terminal updates.

### API Layer (FastAPI)
- **/ws/terminal**: WebSocket — streams live ticks to connected UI clients
- **/ticks**: Historical tick query (proxied to ClickHouse)
- **/quote**: Current price + bid/ask for a symbol (from Redis cache)
- **/ohlcv**: Candlestick data at any resolution (ClickHouse continuous aggregates)
- **/alerts**: CRUD — create/list/delete/toggle alert rules
- **/chat**: Chatbot endpoint — NLP → handler → formatted reply
- **/signals**: ML inference — current signal for a symbol or list
- **/instruments**: Search instruments, get metadata + sector

### Chatbot Layer
- **intent_parser.py**: Calls Claude API with system prompt that extracts structured JSON intent from user message
- **handlers.py**: Routes each intent type to the right data source
- **formatter.py**: Calls Claude API again to format raw data into a conversational reply
- **telegram_bot.py**: Polls Telegram for messages, routes through same handler stack, sends replies + proactive alerts

### ML Layer
- **features.py**: Computes all technical indicators from raw tick data. Runs on each incoming tick for live inference, on historical Parquet for training.
- **regime.py**: Hidden Markov Model — classifies current market into trending/ranging/high-volatility. Output is a feature for downstream models.
- **signals_xgb.py**: XGBoost classifier — buy/sell/hold signal. Takes feature vector (indicators + regime label). Outputs class + confidence + SHAP values.
- **lstm_price.py**: PyTorch LSTM — predicts next N candles. Used for longer-horizon signals.
- **train.py**: Full training pipeline — loads from Parquet, engineers features, trains all models, saves artifacts.

---

## Database Schema Summary

### ClickHouse — `market` database

#### `ticks` table
```sql
ts DateTime64(3, 'Asia/Kolkata')  -- millisecond precision
symbol LowCardinality(String)
ltp Float32
volume UInt32
bid Float32
ask Float32
oi UInt32
bid_qty UInt32
ask_qty UInt32
```
Engine: MergeTree, Partition: toYYYYMM(ts), Order: (symbol, ts)

#### `ohlcv_1m` materialized view
Auto-built from ticks — open, high, low, close, volume per minute per symbol.

---

### PostgreSQL — `market` database

#### `instruments`
symbol, name, sector, market_cap, isin, lot_size, tick_size, updated_at

#### `alerts`
id, user_id, symbol, condition (text), threshold, channel, is_active, triggered_at, created_at

#### `ml_signals`
id, symbol, signal_type (buy/sell/hold), confidence, model, features (JSONB with SHAP), ts

#### `chat_messages`
id, session_id, role, content, intent, ts

#### `trade_journal`
id, order_id, symbol, side, qty, price, regime_label, signal_score, news_sentiment, oi_context, ts

#### `tick_quality`
symbol, date, expected_ticks, received_ticks, gap_count, logged_at

---

## Key Design Decisions

### Why ClickHouse over TimescaleDB?
TimescaleDB is Postgres-based — great for time-series but still row-oriented under the hood. ClickHouse is columnar-native. For read-heavy analytics (ML feature extraction across 500 symbols × 2 years), ClickHouse is 10–100x faster. Storage is also 10x smaller with ZSTD on columnar data.

### Why Kafka over direct write to ClickHouse?
Decoupling. If ClickHouse is slow or down, Kafka buffers ticks. Also enables multiple consumers: the alert engine, feature store updater, and ML pipeline can all read from `ticks.raw` independently without touching each other.

### Why Claude API for chatbot parsing?
A rule-based parser breaks on natural language variation. "Tell me when Reliance breaches its 52-week high" vs "alert if RELIANCE > 52w high" vs "ping me when REL clears the yearly peak" — all the same intent, impossible to enumerate. Claude handles all variations cleanly and returns structured JSON.

### Why Redis for alert rules (not just Postgres)?
The alert evaluator runs on every incoming tick — potentially 2,500/sec. A Postgres query per tick would immediately saturate connections. Redis lookup is sub-millisecond and scales to 100k rules without breaking a sweat.
