# VPS Setup Guide + Build vs Deploy Decision

## Answer First: Build Locally, Deploy to VPS at Phase 2

Here's the decision tree:

```
Q: Should I set up VPS before building?

NO — if you haven't tested the ingestion pipeline yet.
YES — the moment your tick writer is working and you need 24/7 uptime.
```

### Why Build Locally First
- Faster iteration — no SSH round trips to test code changes
- Docker Compose gives you identical infra locally (ClickHouse, Postgres, Kafka, Redis)
- Debugging a WebSocket ingestion bug at 10 AM is much easier on localhost
- You don't pay VPS cost while still figuring out the architecture

### When to Move to VPS (Phase 2 trigger)
Move to VPS when **all three** are true:
1. Your `upstox_ws.py` is running cleanly and writing ticks to ClickHouse
2. You want to capture data 9:15 AM–3:30 PM without keeping your laptop on
3. At least one API endpoint is working (`/ticks`, `/quote`)

That's typically end of Phase 1 / start of Phase 2 in the build plan.

---

## VPS Specifications

### Minimum (Development + Early Production)
| Resource | Spec | Why |
|---|---|---|
| CPU | 4 vCPU | Kafka + ClickHouse + FastAPI concurrent |
| RAM | 16 GB | ClickHouse MergeTree needs memory for merges |
| Disk | 200 GB NVMe SSD | 2 years tick data ~12 GB + OS + logs |
| Network | 1 Gbps | WebSocket feed + API traffic |
| OS | Ubuntu 22.04 LTS | LTS = stable, wide support |

### Recommended (Production with ML)
| Resource | Spec |
|---|---|
| CPU | 8 vCPU |
| RAM | 32 GB |
| Disk | 500 GB NVMe |

### Provider Options (India latency matters for Upstox WS)
| Provider | Instance | Price/month | Notes |
|---|---|---|---|
| **Hetzner** (recommended) | CX31 (4vCPU/8GB) or CX41 (8vCPU/16GB) | ₹1,800–₹3,500 | Best price/perf, Mumbai DC available |
| **DigitalOcean** | 4vCPU/8GB Droplet | ~₹3,200 | Easy UI, Bangalore DC |
| **AWS** | c6i.xlarge | ~₹6,000 | Mumbai region, overkill for start |
| **Contabo** | VPS M (6vCPU/16GB) | ~₹1,500 | Cheapest, but EU latency |

> **Recommendation**: Start with Hetzner CX31 (Mumbai). ₹1,800/month. Upgrade to CX41 when ML training starts.

---

## VPS Setup (Step by Step)

### 1. Initial Server Setup

```bash
# On your LOCAL machine — SSH in
ssh root@YOUR_VPS_IP

# Create non-root user
adduser trader
usermod -aG sudo trader
su - trader

# Harden SSH
sudo nano /etc/ssh/sshd_config
# Set: PasswordAuthentication no
# Set: PermitRootLogin no
sudo systemctl restart sshd

# Firewall
sudo ufw allow OpenSSH
sudo ufw allow 8000/tcp    # FastAPI API
sudo ufw allow 80/tcp      # Nginx HTTP
sudo ufw allow 443/tcp     # Nginx HTTPS
sudo ufw enable
```

### 2. Install Docker

```bash
curl -fsSL https://get.docker.com | sh
sudo usermod -aG docker trader
newgrp docker

# Verify
docker --version
docker compose version
```

### 3. Clone and Configure

```bash
cd /home/trader
git clone <your-repo> nse-terminal
cd nse-terminal

cp .env.example .env
nano .env    # fill in all API keys
```

### 4. Start Infrastructure

```bash
docker compose up -d

# Check all containers are healthy
docker compose ps

# Should show: clickhouse, postgres, kafka, redis — all "Up"
```

### 5. Initialize Databases

```bash
python3 -m venv venv
source venv/bin/activate
pip install -r requirements.txt

# Run DB migrations
python scripts/seed_instruments.py

# Verify ClickHouse schema
docker exec -it clickhouse clickhouse-client \
  --query "SHOW TABLES FROM market"
```

### 6. Set Up Process Management (Supervisord)

```bash
sudo apt install -y supervisor
sudo cp infra/supervisord.conf /etc/supervisor/conf.d/nse-terminal.conf
sudo supervisorctl reread
sudo supervisorctl update
sudo supervisorctl start all

# Check status
sudo supervisorctl status
```

### 7. Nginx Reverse Proxy

```bash
sudo apt install -y nginx
sudo cp infra/nginx.conf /etc/nginx/sites-available/nse-terminal
sudo ln -s /etc/nginx/sites-available/nse-terminal /etc/nginx/sites-enabled/
sudo nginx -t
sudo systemctl reload nginx

# Optional: SSL with Let's Encrypt (if you have a domain)
sudo apt install -y certbot python3-certbot-nginx
sudo certbot --nginx -d yourdomain.com
```

### 8. Verify Everything Works

```bash
# Test API
curl http://YOUR_VPS_IP:8000/health

# Check tick ingestion
docker exec -it clickhouse clickhouse-client \
  --query "SELECT count() FROM market.ticks"
# Should grow during market hours (9:15 AM – 3:30 PM IST)

# Check logs
sudo supervisorctl tail -f ingestion
sudo supervisorctl tail -f api
```

---

## Process Management (`infra/supervisord.conf`)

This file is pre-written at `infra/supervisord.conf` and keeps all services alive 24/7:

```ini
[program:ingestion]
command=/home/trader/nse-terminal/venv/bin/python -m src.ingestion.upstox_ws
directory=/home/trader/nse-terminal
autostart=true
autorestart=true
startretries=10
stderr_logfile=/var/log/nse/ingestion.err.log
stdout_logfile=/var/log/nse/ingestion.out.log

[program:api]
command=/home/trader/nse-terminal/venv/bin/uvicorn src.api.main:app --host 0.0.0.0 --port 8000
directory=/home/trader/nse-terminal
autostart=true
autorestart=true
stderr_logfile=/var/log/nse/api.err.log
stdout_logfile=/var/log/nse/api.out.log

[program:telegram]
command=/home/trader/nse-terminal/venv/bin/python -m src.chatbot.telegram_bot
directory=/home/trader/nse-terminal
autostart=true
autorestart=true
stderr_logfile=/var/log/nse/telegram.err.log
stdout_logfile=/var/log/nse/telegram.out.log
```

---

## Daily Upstox Token Refresh

Upstox access tokens expire every 24 hours. Set up a cron job:

```bash
crontab -e

# Add this line — runs at 8:30 AM IST every day (3:00 UTC)
0 3 * * * cd /home/trader/nse-terminal && venv/bin/python scripts/refresh_token.py >> /var/log/nse/token_refresh.log 2>&1
```

`scripts/refresh_token.py` should use Upstox OAuth refresh flow and update `.env` with the new token.

---

## Monitoring Checklist (Run Daily)

```bash
# 1. Tick count for today
docker exec clickhouse clickhouse-client \
  --query "SELECT count() FROM market.ticks WHERE ts > today()"

# 2. Disk usage
df -h /var/lib/docker

# 3. ClickHouse table size
docker exec clickhouse clickhouse-client \
  --query "SELECT formatReadableSize(sum(bytes_on_disk)) FROM system.parts WHERE table='ticks'"

# 4. Postgres connections
docker exec postgres psql -U trader market \
  -c "SELECT count(*) FROM pg_stat_activity"

# 5. Supervisor status
sudo supervisorctl status
```

---

## Cost Estimate

| Item | Monthly Cost |
|---|---|
| Hetzner CX31 VPS | ₹1,800 |
| Domain (optional) | ₹100 |
| Upstox API (free tier) | ₹0 |
| Anthropic API (chatbot) | ₹500–₹2,000 (depends on usage) |
| Telegram Bot | ₹0 |
| **Total** | **~₹2,400–₹4,000/month** |
