-- ClickHouse initialization script
-- Runs once on first container start

CREATE DATABASE IF NOT EXISTS market;

-- Main tick table
CREATE TABLE IF NOT EXISTS market.ticks (
    ts        DateTime64(3, 'Asia/Kolkata'),
    symbol    LowCardinality(String),
    ltp       Float32,
    volume    UInt32,
    bid       Float32,
    ask       Float32,
    oi        UInt32,
    bid_qty   UInt32,
    ask_qty   UInt32
)
ENGINE = MergeTree()
PARTITION BY toYYYYMM(ts)
ORDER BY (symbol, ts)
TTL ts + INTERVAL 2 YEAR
SETTINGS index_granularity = 8192;

-- 1-minute OHLCV continuous aggregate
CREATE MATERIALIZED VIEW IF NOT EXISTS market.ohlcv_1m
ENGINE = AggregatingMergeTree()
PARTITION BY toYYYYMM(bucket)
ORDER BY (symbol, bucket)
AS SELECT
    symbol,
    toStartOfMinute(ts)         AS bucket,
    argMinState(ltp, ts)        AS open_state,
    maxState(ltp)               AS high_state,
    minState(ltp)               AS low_state,
    argMaxState(ltp, ts)        AS close_state,
    sumState(volume)            AS volume_state
FROM market.ticks
GROUP BY symbol, bucket;

-- 5-minute OHLCV
CREATE MATERIALIZED VIEW IF NOT EXISTS market.ohlcv_5m
ENGINE = AggregatingMergeTree()
PARTITION BY toYYYYMM(bucket)
ORDER BY (symbol, bucket)
AS SELECT
    symbol,
    toStartOfFiveMinutes(ts)    AS bucket,
    argMinState(ltp, ts)        AS open_state,
    maxState(ltp)               AS high_state,
    minState(ltp)               AS low_state,
    argMaxState(ltp, ts)        AS close_state,
    sumState(volume)            AS volume_state
FROM market.ticks
GROUP BY symbol, bucket;

-- Verify
SELECT 'ClickHouse initialized successfully' AS status;
