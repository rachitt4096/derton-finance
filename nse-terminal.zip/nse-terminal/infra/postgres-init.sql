-- PostgreSQL initialization script

CREATE EXTENSION IF NOT EXISTS "uuid-ossp";

-- Instrument master (refreshed monthly from NSE)
CREATE TABLE IF NOT EXISTS instruments (
    symbol          TEXT PRIMARY KEY,
    name            TEXT NOT NULL,
    sector          TEXT,
    market_cap      BIGINT,
    isin            TEXT,
    lot_size        INT DEFAULT 1,
    tick_size       NUMERIC(6,2) DEFAULT 0.05,
    is_fo           BOOLEAN DEFAULT false,    -- F&O eligible
    is_active       BOOLEAN DEFAULT true,
    updated_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_instruments_sector ON instruments(sector);
CREATE INDEX IF NOT EXISTS idx_instruments_market_cap ON instruments(market_cap DESC);

-- User alert rules
CREATE TABLE IF NOT EXISTS alerts (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    user_id         TEXT NOT NULL,
    symbol          TEXT NOT NULL REFERENCES instruments(symbol),
    condition       TEXT NOT NULL,            -- 'price > 2950'
    threshold       NUMERIC,
    condition_type  TEXT NOT NULL,            -- 'price', 'rsi_14', 'volume_spike'
    channel         TEXT DEFAULT 'telegram',  -- 'telegram', 'terminal', 'email'
    is_active       BOOLEAN DEFAULT true,
    triggered_at    TIMESTAMPTZ,
    trigger_count   INT DEFAULT 0,
    created_at      TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_alerts_user ON alerts(user_id);
CREATE INDEX IF NOT EXISTS idx_alerts_symbol_active ON alerts(symbol, is_active);

-- ML signal log
CREATE TABLE IF NOT EXISTS ml_signals (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    symbol          TEXT NOT NULL,
    signal_type     TEXT NOT NULL,            -- 'buy', 'sell', 'hold'
    confidence      FLOAT NOT NULL,
    model           TEXT NOT NULL,            -- 'xgboost_v3', 'lstm_v1'
    regime          TEXT,                     -- 'trending', 'ranging', 'high_vol'
    features        JSONB,                    -- SHAP values + raw feature values
    ts              TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_signals_symbol_ts ON ml_signals(symbol, ts DESC);
CREATE INDEX IF NOT EXISTS idx_signals_type ON ml_signals(signal_type, confidence DESC);

-- Chat history
CREATE TABLE IF NOT EXISTS chat_messages (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    session_id      TEXT NOT NULL,
    user_id         TEXT,
    role            TEXT NOT NULL,            -- 'user', 'assistant'
    content         TEXT NOT NULL,
    intent          TEXT,                     -- parsed intent type
    intent_data     JSONB,                    -- full parsed intent JSON
    ts              TIMESTAMPTZ DEFAULT now()
);

CREATE INDEX IF NOT EXISTS idx_chat_session ON chat_messages(session_id, ts);

-- Auto trade journal
CREATE TABLE IF NOT EXISTS trade_journal (
    id              UUID PRIMARY KEY DEFAULT uuid_generate_v4(),
    order_id        TEXT,                     -- Upstox order ID
    symbol          TEXT NOT NULL,
    side            TEXT NOT NULL,            -- 'BUY', 'SELL'
    qty             INT NOT NULL,
    price           NUMERIC(10,2),
    order_type      TEXT,                     -- 'MARKET', 'LIMIT'
    regime_label    TEXT,                     -- market regime at time of order
    signal_score    FLOAT,                    -- AI signal confidence
    signal_type     TEXT,                     -- buy/sell/hold from ML
    news_sentiment  FLOAT,                    -- -1 to 1
    oi_context      JSONB,                    -- PCR, OI buildup at time
    status          TEXT DEFAULT 'pending',   -- 'pending', 'complete', 'rejected'
    pnl             NUMERIC(12,2),
    ts              TIMESTAMPTZ DEFAULT now()
);

-- Tick quality log
CREATE TABLE IF NOT EXISTS tick_quality (
    symbol          TEXT NOT NULL,
    date            DATE NOT NULL,
    expected_ticks  INT,
    received_ticks  INT,
    gap_count       INT DEFAULT 0,
    max_gap_secs    FLOAT,
    logged_at       TIMESTAMPTZ DEFAULT now(),
    PRIMARY KEY (symbol, date)
);

-- Verify
SELECT 'PostgreSQL initialized successfully' AS status;
