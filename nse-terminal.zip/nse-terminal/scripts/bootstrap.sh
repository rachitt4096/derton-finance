#!/bin/bash
# bootstrap.sh — one-command local setup
# Run: chmod +x scripts/bootstrap.sh && ./scripts/bootstrap.sh

set -e

echo "=== NSE Terminal Bootstrap ==="

# 1. Check prerequisites
command -v docker >/dev/null 2>&1 || { echo "Docker not found. Install from https://docs.docker.com/get-docker/"; exit 1; }
command -v python3 >/dev/null 2>&1 || { echo "Python 3 not found."; exit 1; }

# 2. Check .env exists
if [ ! -f .env ]; then
  echo "ERROR: .env file not found. Run: cp .env.example .env and fill in your API keys."
  exit 1
fi

# 3. Create data directories
mkdir -p data/clickhouse data/postgres data/kafka data/redis
mkdir -p logs models

# 4. Start Docker Compose
echo ""
echo "Starting infrastructure containers..."
docker compose up -d

# 5. Wait for services to be healthy
echo "Waiting for ClickHouse..."
until docker exec clickhouse wget --spider -q http://localhost:8123/ping 2>/dev/null; do
  sleep 2
done
echo "ClickHouse ready."

echo "Waiting for Postgres..."
until docker exec postgres pg_isready -U trader -d market 2>/dev/null; do
  sleep 2
done
echo "Postgres ready."

# 6. Python virtual environment
if [ ! -d venv ]; then
  echo ""
  echo "Creating Python virtual environment..."
  python3 -m venv venv
fi
source venv/bin/activate

echo "Installing Python dependencies..."
pip install -q --upgrade pip
pip install -q -r requirements.txt

# 7. Run DB migrations
echo ""
echo "Running ClickHouse migrations..."
docker exec -i clickhouse clickhouse-client < infra/clickhouse-init.sql

echo "Running Postgres migrations..."
docker exec -i postgres psql -U trader -d market < infra/postgres-init.sql

echo ""
echo "=== Bootstrap Complete ==="
echo ""
echo "Next steps:"
echo "  1. python scripts/seed_instruments.py   — load NSE instrument list"
echo "  2. source venv/bin/activate"
echo "  3. python -m src.ingestion.upstox_ws    — start tick ingestion"
echo "  4. uvicorn src.api.main:app --reload    — start API server"
echo ""
echo "Docker containers running:"
docker compose ps --format "table {{.Name}}\t{{.Status}}"
