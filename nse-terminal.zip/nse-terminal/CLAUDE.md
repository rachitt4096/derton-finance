# NSE Trading Terminal — Claude Code Instructions

## What This Project Is
A full-stack real-time NSE trading terminal with:
- Live tick ingestion for 500+ companies (market cap > ₹10,000 Cr)
- ClickHouse for tick storage, PostgreSQL for relational data
- Kafka for streaming pipeline
- FastAPI backend with WebSocket support
- ML/AI signals (XGBoost → LSTM → regime classifier)
- Conversational chatbot for alerts + queries (powered by Claude API)
- React/JS terminal UI with live charts
- Telegram bot for mobile alerts

## Project Structure
```
nse-terminal/
├── CLAUDE.md                  ← you are here
├── README.md
├── docker-compose.yml         ← spins up ClickHouse + Postgres + Kafka + Redis
├── .env.example               ← copy to .env and fill in secrets
├── docs/
│   ├── architecture.md        ← system design + data flow
│   ├── phase-plan.md          ← what to build in what order
│   ├── vps-setup.md           ← production deployment guide
│   ├── api-reference.md       ← all FastAPI endpoints
│   └── clickhouse-schema.md   ← full DB schema with explanations
├── scripts/
│   ├── bootstrap.sh           ← one-command local setup
│   ├── seed_instruments.py    ← fetch NSE instrument list and populate Postgres
│   └── backfill_history.py    ← pull historical OHLCV via Upstox REST
├── src/
│   ├── ingestion/
│   │   ├── upstox_ws.py       ← Upstox WebSocket client (main tick feed)
│   │   ├── tick_writer.py     ← buffered ClickHouse batch writer
│   │   ├── kafka_producer.py  ← publishes ticks to Kafka topics
│   │   └── watchdog.py        ← gap detection + reconnect logic
│   ├── api/
│   │   ├── main.py            ← FastAPI app entry point
│   │   ├── routes/
│   │   │   ├── ticks.py       ← GET ticks, OHLCV, quote endpoints
│   │   │   ├── alerts.py      ← CRUD for alert rules
│   │   │   ├── chat.py        ← /chat endpoint (LLM NLP layer)
│   │   │   ├── signals.py     ← ML inference endpoints
│   │   │   └── instruments.py ← instrument search + metadata
│   │   ├── db/
│   │   │   ├── clickhouse.py  ← CH client singleton
│   │   │   └── postgres.py    ← asyncpg pool singleton
│   │   └── alert_engine.py    ← tick → rule evaluator → Telegram push
│   ├── ml/
│   │   ├── features.py        ← RSI, MACD, OFI, VWAP, etc.
│   │   ├── regime.py          ← HMM market regime classifier
│   │   ├── signals_xgb.py     ← XGBoost buy/sell/hold model
│   │   ├── lstm_price.py      ← LSTM sequence model
│   │   └── train.py           ← training pipeline entry point
│   ├── chatbot/
│   │   ├── intent_parser.py   ← Claude API NLP → structured JSON intent
│   │   ├── handlers.py        ← routes intents to data/alert/ML handlers
│   │   ├── formatter.py       ← formats raw data into natural language reply
│   │   └── telegram_bot.py    ← Telegram Bot API integration
│   └── ui/
│       ├── index.html
│       ├── terminal.js        ← main terminal logic
│       ├── chat_panel.js      ← floating chatbot UI
│       └── charts.js          ← Lightweight Charts integration
└── infra/
    ├── nginx.conf             ← reverse proxy config
    ├── supervisord.conf       ← process management on VPS
    └── systemd/               ← systemd service files
```

---

## Tech Stack

| Layer | Tech | Why |
|---|---|---|
| Tick storage | ClickHouse | Columnar, ZSTD compression, 500M rows/sec inserts |
| Relational | PostgreSQL 16 | Alerts, instruments, signals, chat history |
| Streaming | Kafka (KRaft mode) | Decouples ingestion from processing |
| Cache / pub-sub | Redis | Alert rule hot cache, WebSocket fanout |
| Backend | FastAPI + asyncpg | Async, fast, WebSocket native |
| ML | scikit-learn, XGBoost, PyTorch | Baseline → deep learning progression |
| LLM / Chatbot | Claude API (claude-sonnet-4-20250514) | Intent parsing + reply formatting |
| Frontend | Vanilla JS + Lightweight Charts | No framework bloat, fast rendering |
| Alerts | Telegram Bot API | Client already on phone all day |
| Infra | Docker Compose (dev) → VPS (prod) | |

---

## Environment Variables (`.env`)
```env
# Upstox
UPSTOX_API_KEY=
UPSTOX_API_SECRET=
UPSTOX_ACCESS_TOKEN=        # refresh daily via OAuth flow
UPSTOX_WS_URL=wss://api.upstox.com/v2/feed/market-data-feed

# ClickHouse
CLICKHOUSE_HOST=localhost
CLICKHOUSE_PORT=9000
CLICKHOUSE_DB=market
CLICKHOUSE_USER=default
CLICKHOUSE_PASSWORD=

# PostgreSQL
POSTGRES_DSN=postgresql://trader:secret@localhost:5432/market

# Kafka
KAFKA_BOOTSTRAP=localhost:9092
KAFKA_TOPIC_TICKS=ticks.raw
KAFKA_TOPIC_OHLCV=ticks.ohlcv.1m
KAFKA_TOPIC_ALERTS=alerts.eval

# Redis
REDIS_URL=redis://localhost:6379

# Claude API (for chatbot NLP)
ANTHROPIC_API_KEY=

# Telegram
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=           # client's chat ID

# App
API_HOST=0.0.0.0
API_PORT=8000
DEBUG=true
```

---

## How Claude Code Should Work on This Project

### General Rules
1. **Always use async/await** — everything is async: DB queries, HTTP calls, WebSocket handlers
2. **Never insert ticks one at a time into ClickHouse** — buffer minimum 1 second or 5000 rows, then batch insert
3. **Never call Upstox order API without a user confirmation step** — always echo back parsed order and wait for "YES"
4. **Use `LowCardinality(String)`** for the `symbol` column in ClickHouse — it compresses 500 repeated names to near-zero
5. **Load `.env` via `python-dotenv`** at startup — never hardcode credentials
6. **All FastAPI routes return consistent JSON** — `{success: bool, data: any, error: str|null}`

### When Writing the Ingestion Service (`src/ingestion/`)
- The Upstox WS sends a protobuf feed — decode using their `MarketDataFeed_pb2` generated file
- Maintain a `symbols_to_subscribe` list loaded from Postgres `instruments` table at startup
- Reconnect with exponential backoff (1s, 2s, 4s… max 60s) on disconnect
- Push each decoded tick to both: (a) Kafka `ticks.raw` topic and (b) in-memory `TickWriter` buffer for ClickHouse
- Log dropped ticks and gaps to a `tick_quality` table in Postgres

### When Writing the API (`src/api/`)
- Tick queries → ClickHouse only
- Alert CRUD → Postgres only
- Active alert rules → Redis (loaded from Postgres on startup, kept in sync)
- All `/chat` requests → `intent_parser.py` → handler → `formatter.py` → response

### When Writing the Chatbot (`src/chatbot/`)
- System prompt for intent parsing must instruct the model to return **only valid JSON**, no prose, no markdown
- Intent schema:
```json
{
  "intent": "alert_set | alert_cancel | market_query | ml_signal | order_place | general",
  "symbol": "RELIANCE | NIFTY | null",
  "condition": "price > 2950 | rsi_14 < 30 | null",
  "threshold": 2950.0,
  "timeframe": "1d | 1h | null",
  "raw": "original user message"
}
```
- After getting intent JSON, call the appropriate handler, then call Claude API **again** to format the result into a friendly reply
- For `order_place` intent: always return a confirmation message and set `pending_order` in session state — only execute on next message containing "YES" or "CONFIRM"

### When Writing ML Models (`src/ml/`)
- Always train on **compressed Parquet exports** from ClickHouse, not live DB
- Feature vector must include: RSI(14), MACD(12,26,9), BB(%B), ATR(14), VWAP deviation, OFI(10), volume_z_score, bid_ask_spread, regime_label
- Regime classifier runs first — output feeds as a feature into XGBoost signal model
- Save models as `.joblib` (sklearn/XGBoost) or `.pt` (PyTorch) in `models/` directory
- Log all inference results to `ml_signals` table in Postgres with SHAP values as JSONB

### When Writing the UI (`src/ui/`)
- Lightweight Charts for all candlestick/line charts — no TradingView, no heavyweight libs
- Chat panel is a floating `<div>` overlay — `position: fixed; bottom: 20px; right: 20px`
- Connect to FastAPI via WebSocket at `/ws/terminal` for live tick updates
- Chatbot messages POST to `/chat` endpoint, display streamed response token by token if using streaming

---

## Build Order (Follow This Sequence)

### Phase 0 — Local infra (do this first, ~1 hour)
```bash
cp .env.example .env        # fill in your Upstox + API keys
./scripts/bootstrap.sh      # starts Docker containers, runs migrations
python scripts/seed_instruments.py  # populates instruments table from NSE
```

### Phase 1 — Ingestion pipeline
Build in this order:
1. `src/ingestion/tick_writer.py` — ClickHouse buffered writer (test with mock data first)
2. `src/ingestion/kafka_producer.py` — Kafka publisher
3. `src/ingestion/upstox_ws.py` — connect to Upstox, decode feed, push to above two
4. `src/ingestion/watchdog.py` — reconnect logic + gap detection
5. Verify: run for 30 minutes during market hours, check ClickHouse row count

### Phase 2 — API layer
1. `src/api/db/` — DB client singletons
2. `src/api/routes/ticks.py` — basic quote + OHLCV endpoints
3. `src/api/routes/alerts.py` — alert CRUD
4. `src/api/alert_engine.py` — evaluates rules on each tick, pushes to Telegram
5. `src/api/main.py` — wire everything up

### Phase 3 — Chatbot
1. `src/chatbot/intent_parser.py` — Claude API NLP
2. `src/chatbot/handlers.py` — one handler per intent type
3. `src/chatbot/formatter.py` — natural language response generator
4. `src/api/routes/chat.py` — expose via FastAPI
5. `src/chatbot/telegram_bot.py` — mobile interface

### Phase 4 — ML
1. `src/ml/features.py` — full feature engineering
2. `src/ml/regime.py` — train regime classifier first
3. `src/ml/signals_xgb.py` — XGBoost signal model with regime as input
4. `src/api/routes/signals.py` — serve inference via API

### Phase 5 — UI
1. Basic terminal layout with live tick table
2. Lightweight Charts integration
3. Chat panel overlay
4. Signal dashboard

---

## Key Commands

```bash
# Start all infra
docker compose up -d

# Seed instruments from NSE
python scripts/seed_instruments.py

# Run ingestion service (keep alive)
python -m src.ingestion.upstox_ws

# Run API server
uvicorn src.api.main:app --reload --host 0.0.0.0 --port 8000

# Run Telegram bot
python -m src.chatbot.telegram_bot

# Train ML models (run after market hours)
python -m src.ml.train

# Check ClickHouse tick count
docker exec -it clickhouse clickhouse-client --query \
  "SELECT symbol, count() FROM market.ticks GROUP BY symbol ORDER BY count() DESC LIMIT 10"
```

---

## Common Pitfalls (Avoid These)

| Pitfall | Fix |
|---|---|
| Inserting ticks one-by-one to ClickHouse | Always batch — minimum 1s or 5000 rows |
| Querying Postgres for tick data | Never — ticks only live in ClickHouse |
| Running ML training during market hours | Only train after 4 PM or on weekends |
| Not handling Upstox token refresh | Access token expires daily — build auto-refresh |
| Blocking async event loop with ML inference | Use `asyncio.to_thread()` for CPU-bound inference |
| Sending orders without confirmation | Always echo + require "YES" before placing |
| Storing raw ticks in Redis | Redis is for alert rules only — not tick history |

---

## References
- Upstox WebSocket docs: https://upstox.com/developer/api-documentation/market-data-feed
- ClickHouse Python driver: https://clickhouse-driver.readthedocs.io
- Kafka Python: https://kafka-python.readthedocs.io
- Claude API: https://docs.anthropic.com/en/api/messages
- Lightweight Charts: https://tradingview.github.io/lightweight-charts/
- Telegram Bot API: https://core.telegram.org/bots/api
