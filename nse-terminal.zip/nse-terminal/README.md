# NSE Trading Terminal

Real-time terminal for NSE-listed companies (market cap > ₹10,000 Cr) with ML signals, conversational alerts, and full tick history.

## Features
- Live tick ingestion via Upstox WebSocket (500+ stocks)
- ClickHouse tick DB — 2 years of history in ~12 GB
- Conversational chatbot — set alerts in plain English
- ML signals: regime detection → XGBoost → LSTM
- Telegram mobile alerts
- Order flow imbalance, SHAP explainability, auto trade journal

## Quick Start

```bash
git clone <repo>
cd nse-terminal
cp .env.example .env          # add your keys
./scripts/bootstrap.sh        # Docker up + DB migrations
python scripts/seed_instruments.py
uvicorn src.api.main:app --reload
```

Open `src/ui/index.html` in your browser.

## Docs
- [Architecture](docs/architecture.md)
- [Phase Build Plan](docs/phase-plan.md)
- [VPS Deployment](docs/vps-setup.md)
- [API Reference](docs/api-reference.md)
- [ClickHouse Schema](docs/clickhouse-schema.md)

## Prerequisites
- Python 3.11+
- Docker + Docker Compose
- Upstox Developer account with API access
- Anthropic API key (for chatbot)
- Telegram Bot token
